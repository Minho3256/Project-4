# Project-4
# This is a dancing robot.
# If you press key w, robot will move theire arms like wave.
# If you press key d, robot will dance.
# After the robot ends its movement, you can press key w or d again.
