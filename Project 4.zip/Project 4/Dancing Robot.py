# Draw a robot arm with multiple joints, controlled with keyboard inputs
#
# -*- coding: utf-8 -*- 

import pygame
import numpy as np
import random
import os



# 게임 윈도우 크기
WINDOW_WIDTH = 1000
WINDOW_HEIGHT = 700

# 색 정의
BLACK = (0, 0, 0)
WHITE = (255,255,255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW=(255,212,100)
GREY=(255, 212, 100)
NAVY=(0,0,20)
FLOOR=(50,50,200)
SKY=(80,188,223)

def Rmat(degree):
    radian = np.deg2rad(degree)
    c = np.cos(radian)
    s = np.sin(radian)
    R = np.array( [[ c, -s, 0], [s, c, 0], [0, 0, 1] ] )
    return R

def Tmat(a,b):
    H = np.eye(3)
    H[0,2] = a
    H[1,2] = b
    return H


# Pygame 초기화
pygame.init()

current_path = os.path.dirname(__file__)
assets_path = os.path.join(current_path, 'BGM')
pygame.mixer.music.load(os.path.join(assets_path, 'BGM2.wav'))
pygame.mixer.music.play(-1)

# 윈도우 제목
pygame.display.set_caption("Drawing")

# 윈도우 생성
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

# 게임 화면 업데이트 속도
clock = pygame.time.Clock()

# 게임 종료 전까지 반복
done = False

# poly: 4 x 3 matrix
poly = np.array( [[0, 0, 1], [100, 0, 1], [100, 20, 1], [0, 20, 1]])
poly = poly.T # 3x4 matrix 

body= np.array([[0,0,1],[90,0,1],[90,20,1],[60,20,1],
                [60,40,1],[30,40,1],[30,20,1],[0,20,1]])
body=body.T

abd=np.array([[0,0,1],[30,0,1],[30,100,1],[40,100,1],[40,120,1],[-10,120,1],[-10,100,1],[0,100,1]])
abd=abd.T

Rhand = np.array([[0,0,1],[40,0,1],[40,10,1],[20,10,1],[20,20,1],[0,20,1]])
Rhand=Rhand.T

Lhand = np.array([[0,0,1],[40,0,1],[40,20,1],[20,20,1],[20,10,1],[0,10,1]])
Lhand=Lhand.T

head = np.array([[0,0,1],[60,0,1],[60,60,1],[0,60,1]])
head=head.T

leg=np.array([[0,0,1],[20,0,1],[20,100,1],[0,100,1]])
leg=leg.T

light=np.array([[0,0,1],[30,0,1],[50,500,1],[-20,500,1]])
light=light.T

cor = np.array([10, 10, 1])
cor2 = np.array([90, 10, 1])
cor3=np.array([45,30,1])

Bdegree=0

R1degree=0
R2degree=0
Rhdegree=0

L1degree=0
L2degree=0
Lhdegree=0

LL1degree=15
LL2degree=-15
RL1degree=-15
RL2degree=15
Abddegree =0

Light1Degree=-30
Light2Degree=-30
Light3Degree=30
Light4Degree=30

Bcnt=0
R1c=0
R2c=0
Rhc=0
L1c=0
L2c=0
Lhc=0
LL1c=0
LL2c=0
RL1c=0
RL2c=0
Abdc=0

Bw=0
R1w=0
R2w=0
Rhw=0
L1w=0
L2w=0
Lhw=0
LL1w=0
LL2w=0
RL1w=0
RL2w=0
Abdw=0
Light1w=0
Light2w=0
Light3w=0
Light4w=0

FPS=60
DANCE=False
WAVE= False

# 게임 반복 구간
while not done:
    # 이벤트 반복 구간
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                WAVE=True
                
            elif event.key == pygame.K_d:
                DANCE=True

    # 윈도우 화면 채우기
    screen.fill(NAVY)
    
    pygame.draw.polygon(screen, FLOOR, [(300,450),(250,677),(750,675),(700,450)])
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    LIGHT=(r,g,b)
    
    Light1Degree+=Light1w
    HLIGHT1= Tmat(300,50) @ Tmat(15,0) @ Rmat(Light1Degree) @ Tmat(-15,0)
    plight1=HLIGHT1 @ light
    qlight1=plight1[0:2,:].T
    pygame.draw.polygon(screen, LIGHT, qlight1)
    if Light1Degree >=30 :
            Light1w = -0.6
    elif Light1Degree <=-30:
            Light1w = 0.6

    Light2Degree+=Light2w
    HLIGHT2= Tmat(400,50) @ Tmat(15,0) @ Rmat(Light2Degree) @ Tmat(-15,0)
    plight2=HLIGHT2 @ light
    qlight2=plight2[0:2,:].T
    pygame.draw.polygon(screen, LIGHT, qlight2)
    if Light2Degree >=30 :
            Light2w = -0.4
    elif Light2Degree <=-30:
            Light2w = 0.4

    Light3Degree+=Light3w
    HLIGHT3= Tmat(600,50) @ Tmat(15,0) @ Rmat(Light3Degree) @ Tmat(-15,0)
    plight3=HLIGHT3 @ light
    qlight3=plight3[0:2,:].T
    pygame.draw.polygon(screen, LIGHT, qlight3)
    if Light3Degree >=30 :
            Light3w = -0.4
    elif Light3Degree <=-30:
            Light3w = 0.4
    
    Light4Degree+=Light4w
    HLIGHT4= Tmat(700,50) @ Tmat(15,0) @ Rmat(Light4Degree) @ Tmat(-15,0)
    plight4=HLIGHT4 @ light
    qlight4=plight4[0:2,:].T
    pygame.draw.polygon(screen, LIGHT, qlight4)
    if Light4Degree >=30 :
            Light4w = -0.6
    elif Light4Degree <=-30:
            Light4w = 0.6
    #font = pygame.font.SysFont('FixedSys', 30, True, False)
    #textm=font.render("Auto mode : Q  Control mode : Z",True, BLACK)
    #screen.blit(textm, [30, 30])
    
    for i in range(100):
        x=random.randint(0,1000)
        y=random.randint(0,700)
        pygame.draw.circle(screen, LIGHT, (x,y), 3)

    Lhdegree+=Lhw
    Rhdegree+=Rhw
    Bdegree+=Bw
    L1degree+=L1w
    L2degree+=L2w
    R1degree+=R1w
    R2degree+=R2w

    LL1degree+=L1w
    LL2degree+=L2w
    RL1degree+=R1w
    RL2degree+=R2w

    Abddegree+=Abdw

    if DANCE:
        #LEFT HAND
        if Lhc == 0:
            Lhw=1
        if Lhc >= 6 and Lhdegree==0:
            Lhw=0
        if Lhdegree >=30 :
            Lhw = -1
            Lhc+=1
        elif Lhdegree <=-30:
            Lhw = 1
            Lhc+=1

        #LEFT ARM2
        if L2c == 0:
            L2w=1
        if L2c >= 6 and L2degree==0:
            L2w=0
        if L2degree >=30 :
            L2w = -1
            L2c+=1
        elif L2degree <=-30:
            L2w = 1
            L2c+=1

        #LEFT ARM1
        if L1c == 0:
            L1w=1
        if L1c >= 6 and L1degree==0:
            L1w=0
        if L1degree >=30 :
            L1w = -1
            L1c+=1
        elif L1degree <=-30:
            L1w = 1
            L1c+=1

        #BODY
        if Bcnt == 0:
            Bw=1
        if Bcnt >= 6 and Bdegree==0:
            Bw=0
        if Bdegree >=30 :
            Bw = -1
            Bcnt+=1
        elif Bdegree <=-30:
            Bw = 1
            Bcnt+=1

        #ABDOMEN
        if Abdc == 0:
            Abdw=1
        if Abdc >= 6 and Abddegree==0:
            Abdw=0
        if Abddegree >=30 :
            Abdw = -1
            Abdc+=1
        elif Abddegree <=-30:
            Abdw = 1
            Abdc+=1

        #RIGHT ARM1
        if R1c == 0:
            R1w=1
        if R1c >= 6 and R1degree==0:
            R1w=0
        if R1degree >=30 :
            R1w = -1
            R1c+=1
        elif R1degree <=-30:
            R1w = 1
            R1c+=1

        #RIGHT ARM2
        if R2c == 0:
            R2w=1
        if R2c >= 6 and R2degree==0:
            R2w=0
        if R2degree >=30 :
            R2w = -1
            R2c+=1
        elif R2degree <=-30:
            R2w = 1
            R2c+=1

        #RIGHT HAND
        if Rhc == 0:
            Rhw=1
        if Rhc >= 6 and Rhdegree==0:
            Rhw=0
        if Rhdegree >=30 :
            Rhw = -1
            Rhc+=1
        elif Rhdegree <=-30:
            Rhw = 1
            Rhc+=1

        if Rhc >= 6 and Rhdegree==0:
            Bcnt=0
            R1c=0
            R2c=0
            Rhc=0
            L1c=0
            L2c=0
            Lhc=0
            Abdc=0
            DANCE=False


    if WAVE:

        #LEFT HAND
        if Lhc == 0:
            Lhw=2
        if Lhc >= 2 and Lhdegree==0:
            Lhw=0
        if Lhdegree >=60 :
            Lhw = -2
            Lhc+=1
        elif Lhdegree <=-60:
            Lhw = 2
            Lhc+=1

        #LEFT ARM2
        if L2c == 0 and Lhc==1 and Lhdegree==0:
            L2w=-2
        if L2c >= 2 and L2degree==0:
            L2w=0
        if L2degree >=60 :
            L2w = -2
            L2c+=1
        elif L2degree <=-60:
            L2w = 2
            L2c+=1

        #LEFT ARM1
        if L1c == 0 and Lhc==1 and Lhdegree==0:
            L1w=1
        if L1c >= 2 and L1degree==0:
            L1w=0
        if L1degree >=30 :
            L1w = -1
            L1c+=1
        elif L1degree <=-30:
            L1w = 1
            L1c+=1

        #BODY
        if Bcnt == 0 and L1c==1:
            Bw=0.5# 1
        if Bcnt >= 1 and Bdegree==0:
            Bw=0
        if Bdegree >=15 :
            Bw = -0.5
            Bcnt+=1
        elif Bdegree <=-15:
            Bw = 0.5
            Bcnt+=1

        #RIGHT ARM1
        if R1c == 0 and L1c==1:
            R1w=-1
        if R1c >= 2 and R1degree==0:
            R1w=0
        if R1degree >=30 :
            R1w = -1
            R1c+=1
        elif R1degree <=-30:
            R1w = 1
            R1c+=1

        #RIGHT ARM2
        if R2c == 0 and L1c==1:
            R2w=2
        if R2c >= 2 and R2degree==0:
            R2w=0
        if R2degree >=60 :
            R2w = -2
            R2c+=1
        elif R2degree <=-60:
            R2w = 2
            R2c+=1
        #RIGHT HAND
        if Rhc == 0 and R2c==1:
            Rhw=2
        if Rhc >= 2 and Rhdegree==0:
            Rhw=0
        if Rhdegree >=60 :
            Rhw = -2
            Rhc+=1
        elif Rhdegree <=-60:
            Rhw = 2
            Rhc+=1

        if Rhc >= 2 and Rhdegree==0:
            Bcnt=0
            R1c=0
            R2c=0
            Rhc=0
            L1c=0
            L2c=0
            Lhc=0
            LL1c=0
            LL2c=0
            RL1c=0
            RL2c=0
            Abdc=0
            WAVE=False

    

    #ABDOMEN
    HA=Tmat(485,300) @ Tmat(45,10) @ Rmat(Abddegree) @ Tmat(-45,-10)
    ppp=HA @ abd
    qp=ppp[0:2,:].T
    pygame.draw.polygon(screen, WHITE,qp,0)
    pygame.draw.polygon(screen, BLACK,qp,3)

    #HEAD
    HH=HA@Tmat(-15,-85) @ Tmat(30,65) @ Rmat(0) @ Tmat(-30,-65)
    pph=HH@head
    qh=pph[0:2,:].T
    corh=HH@[30,65,1]
    core1=HH@[15,20,1]
    core2=HH@[45,20,1]
    corn=HH@[30,25,1]
    corm=HH@[30,45,1]
    pygame.draw.circle(screen,YELLOW,corh[:2],5)
    pygame.draw.polygon(screen, YELLOW,qh,0)
    pygame.draw.polygon(screen, BLACK,qh,3)
    pygame.draw.circle(screen,WHITE,core1[:2],7)
    pygame.draw.circle(screen,BLACK,core1[:2],4)
    pygame.draw.circle(screen,WHITE,core2[:2],7)
    pygame.draw.circle(screen,BLACK,core2[:2],4)
    pygame.draw.circle(screen,BLACK,corn[:2],5,3)
    pygame.draw.circle(screen,BLACK,corm[:2],10,3)
    
    
    

    #BODY
    HB=HA@Tmat(-30,-20) @ Tmat(45,30) @ Rmat(Bdegree) @ Tmat(-45,-30)
    ppb=HB@body
    qb=ppb[0:2,:].T
    corpp = HB @ cor3
    pygame.draw.polygon(screen, WHITE,qb,0)
    pygame.draw.polygon(screen, BLACK,qb,3)
    
    #RIGHT ARM
    HR1 = HB @ Tmat(70,0) @ Tmat(10, 10) @ Rmat(R1degree) @ Tmat(-10, -10)
    pp = HR1 @ poly
    corp = HR1 @ cor #점e
    # print(pp.shape, pp, pp.T )
    q = pp[0:2, :].T # N x 2 matrix
    pygame.draw.polygon(screen, WHITE, q, 0)
    pygame.draw.polygon(screen, BLACK, q, 3)
    
    HR2 = HR1 @ Tmat(100,0) @ Tmat(-10,10) @ Rmat(R2degree) @ Tmat(-10,-10)
    pp2 = HR2 @ poly
    corp2 = HR2 @ cor #점
    q2=pp2[0:2,:].T
    pygame.draw.polygon(screen, YELLOW, q2, 0)
    pygame.draw.polygon(screen, BLACK, q2, 3)

    HRH = HR2 @ Tmat(100,0) @ Tmat(0,10) @ Rmat(Rhdegree) @ Tmat(0,-10)
    pprh = HRH @ Rhand
    qrh = pprh[0:2,:].T
    pygame.draw.polygon(screen, YELLOW, qrh, 0)
    pygame.draw.polygon(screen, BLACK, qrh, 3)



    #LEFT ARM
    HL1 = HB @ Tmat(-80,0) @ Tmat(90,10) @ Rmat(L1degree) @ Tmat(-90,-10)
    pp3 = HL1 @ poly
    corp3 = HL1 @ cor2 #점
    q3=pp3[0:2,:].T
    pygame.draw.polygon(screen, WHITE, q3, 0)
    pygame.draw.polygon(screen, BLACK, q3, 3)

    HL2 = HL1 @ Tmat(100,0) @ Tmat(-90,10) @ Rmat(L2degree) @ Tmat(-90,-10)
    pp4 = HL2 @ poly
    corp4 = HL2 @ cor2 #점
    q4=pp4[0:2,:].T
    pygame.draw.polygon(screen, YELLOW, q4, 0)
    pygame.draw.polygon(screen, BLACK, q4, 3)

    HLH = HL2 @ Tmat(-40,0) @ Tmat(40,10) @ Rmat(Lhdegree) @ Tmat(-40,-10)
    pplh = HLH @ Lhand
    qlh = pplh[0:2,:].T
    pygame.draw.polygon(screen, YELLOW, qlh, 0)
    pygame.draw.polygon(screen, BLACK, qlh, 3)


    #LEFT LEG
    HLL1 = HA @ Tmat(-10,100) @ Tmat(10,10) @ Rmat(LL1degree) @ Tmat(-10,-10)
    ppll1 = HLL1 @ leg
    corp3 = HLL1 @ cor #점
    qll1=ppll1[0:2,:].T
    
   
    HLL2= HLL1 @ Tmat(0,80) @ Tmat(10,10) @ Rmat(LL2degree) @ Tmat(-10,-10)
    ppll2 = HLL2 @ leg
    corp3 = HLL2 @ cor #점
    qll2=ppll2[0:2,:].T
    pygame.draw.polygon(screen, SKY, qll2, 0)
    pygame.draw.polygon(screen, BLACK, qll2, 3)
    
    pygame.draw.polygon(screen, SKY, qll1, 0)
    pygame.draw.polygon(screen, BLACK, qll1, 3)



    #RIGHT LEG
    HRL1 = HA @ Tmat(20,100) @ Tmat(10,10) @ Rmat(RL1degree) @ Tmat(-10,-10)
    pprl1 = HRL1 @ leg
    corp3 = HRL1 @ cor #점
    qrl1=pprl1[0:2,:].T
    

    HRL2= HRL1 @ Tmat(0,80) @ Tmat(10,10) @ Rmat(RL2degree) @ Tmat(-10,-10)
    pprl2 = HRL2 @ leg
    corp3 = HRL2 @ cor #점
    qrl2=pprl2[0:2,:].T
    pygame.draw.polygon(screen, SKY, qrl2, 0)
    pygame.draw.polygon(screen, BLACK, qrl2, 3)
    
    pygame.draw.polygon(screen, SKY, qrl1, 0)
    pygame.draw.polygon(screen, BLACK, qrl1, 3)
    

    
    # 화면 업데이트
    pygame.display.flip()
    clock.tick(FPS)

    # 게임 종료
pygame.quit()